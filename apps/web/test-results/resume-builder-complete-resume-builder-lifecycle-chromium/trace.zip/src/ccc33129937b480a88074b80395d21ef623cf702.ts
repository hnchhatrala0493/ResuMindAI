import { expect, test } from '@playwright/test';
const email = 'test@example.com',
  password = 'Test@Resume123';
async function login(page: import('@playwright/test').Page) {
  await page.goto('/login');
  await page.getByLabel('Email address').fill(email);
  await page.locator('input[name="password"]').fill(password);
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL(/dashboard/);
}
test('complete resume builder lifecycle', async ({ page }) => {
  await login(page);
  await page.goto('/dashboard/resumes');
  await page.getByRole('button', { name: /Create resume/i }).click();
  await page.getByPlaceholder('Resume title').fill('Playwright QA Resume');
  await page.getByPlaceholder('Target role').fill('Senior Engineer');
  await page.getByRole('button', { name: 'Start from blank' }).click();
  await expect(page).toHaveURL(/\/edit/);
  await page.getByLabel('First name').fill('Playwright');
  await page.getByLabel('Last name').fill('Tester');
  await page.getByLabel('Email').fill(email);
  await page
    .getByRole('combobox')
    .filter({ has: page.locator('option') })
    .first();
  await page
    .locator('select')
    .filter({ hasText: 'Professional Summary' })
    .selectOption('professionalSummary');
  await page
    .getByLabel('Summary')
    .fill(
      'Experienced engineer delivering measurable, accessible and reliable products for global customers.',
    );
  await expect(page.getByRole('status')).toContainText(/Saved/, { timeout: 10000 });
  await page.reload();
  await expect(page.getByText(/Playwright QA Resume/)).toBeVisible();
  await page.locator('select').filter({ hasText: 'Modern' }).first().selectOption('technical');
  await expect(page.getByRole('status')).toContainText(/Saved/, { timeout: 10000 });
  await page.goto('/dashboard/resumes');
  const card = page.locator('article').filter({ hasText: 'Playwright QA Resume' });
  await card.getByLabel('Duplicate').click();
  await expect(
    page.locator('article').filter({ hasText: 'Playwright QA Resume Copy' }),
  ).toBeVisible();
  const copy = page.locator('article').filter({ hasText: 'Playwright QA Resume Copy' });
  await copy.getByLabel('Archive').click();
  await page.locator('select').filter({ hasText: 'Archived' }).selectOption('archived');
  await expect(
    page.locator('article').filter({ hasText: 'Playwright QA Resume Copy' }),
  ).toBeVisible();
  await page
    .locator('article')
    .filter({ hasText: 'Playwright QA Resume Copy' })
    .getByLabel('Restore')
    .click();
  await page.locator('select').filter({ hasText: 'All active' }).selectOption('');
  page.once('dialog', (d) => d.accept());
  await page
    .locator('article')
    .filter({ hasText: 'Playwright QA Resume' })
    .getByLabel('Delete')
    .click();
});
for (const [name, width, height] of [
  ['375x667', 375, 667],
  ['390x844', 390, 844],
  ['768x1024', 768, 1024],
  ['1024x768', 1024, 768],
  ['1280x800', 1280, 800],
  ['1440x900', 1440, 900],
  ['1920x1080', 1920, 1080],
] as const)
  test(`responsive screenshots ${name}`, async ({ page }, info) => {
    await page.setViewportSize({ width, height });
    await page.goto('/');
    await expect(page.getByRole('heading', { name: /Build a Resume That/i })).toBeVisible();
    await expect(page.locator('body')).toHaveJSProperty('scrollWidth', width);
    await page.screenshot({ path: info.outputPath(`landing-${name}.png`), fullPage: true });
    await page.goto('/login');
    await expect(page.getByRole('heading', { name: /Sign in to ResuMind/i })).toBeVisible();
    await page.screenshot({ path: info.outputPath(`login-${name}.png`), fullPage: true });
  });
